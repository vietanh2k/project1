import java.util.Scanner;

public class main {
    public static void main(String arg[]){
        int n;
        Scanner scanner = new Scanner(System.in);
        System.out.println("nhap n = ");
        n = scanner.nextInt();
        StackOfInterger stack = new StackOfInterger();
        for(int i = n; i>= 1; i--){
            if(stack.isPrimeNumber(i)){
                System.out.print(i+" ");
            }
        }
    }
}
