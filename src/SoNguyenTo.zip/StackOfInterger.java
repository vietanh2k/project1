public class StackOfInterger {
    public int[] elements;
    public int size;

    public StackOfInterger(){
        this.elements = new int[16];
    }

    public StackOfInterger(int capacity){
        this.elements = new int[capacity];
    }

    public boolean isEmpty(){
        if(this.size == 0){
            return true;
        }
        return false;
    }

    public boolean isFull(){
        if(this.size == this.elements.length){
            return true;
        }
        return false;
    }

    public int peak(){
        return this.elements[this.size-1];
    }

    public void push(int value){
        this.elements[this.size] = value;
        this.size ++;
    }

    public int pop(){
        int tmp = this.elements[this.size-1];
        this.size --;
        return tmp;
    }

    public int getSize(){
        return this.size;
    }

    public boolean isPrimeNumber(int k){
        if(k >= 0 && k <=2 ) return true;

        for(int i= 2; i < k/2+1; i++){
            if(k % i == 0) return false;
        }
        return true;
    }
}
